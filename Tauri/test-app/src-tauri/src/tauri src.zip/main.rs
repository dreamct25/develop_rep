// Prevents additional console window on Windows in release, DO NOT REMOVE!!
#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

use mysql::prelude::Queryable;

mod mysql_config;

// Learn more about Tauri commands at https://tauri.app/v1/guides/features/command
#[tauri::command]
fn greet(name: &str) -> String {
    format!("Hello, {}! You've been greeted from Rust!", name)
}

#[tauri::command]
fn print_some(say: bool) -> String {
    if say {
        format!("Hello Rust from backend")
    } else {
        format!("OMG false !!!")
    }
}

#[tauri::command]
fn select_all_data() -> String {
    return mysql_config::use_mysql::<String>(|connect| {
        let result_temp:Result<Vec<mysql_config::Person>, mysql::Error> = connect.query_map("SELECT * FROM person",|(uuid,name,old,create_date)| mysql_config::Person {
            uuid,
            name,
            old,
            create_date
        });

        let result = match result_temp {
            Ok(res) => serde_json::to_string(&res).unwrap(),
            Err(err) => {
                let empty_array:Vec<mysql_config::Person> = vec![];
                println!("{}",err);
                serde_json::to_string(&empty_array).unwrap()
            }
        };

        println!("{:?}",result);

        result
    });
}

fn main() {
    tauri::Builder::default()
        .invoke_handler(tauri::generate_handler![greet])
        .invoke_handler(tauri::generate_handler![print_some])
        .invoke_handler(tauri::generate_handler![select_all_data])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
