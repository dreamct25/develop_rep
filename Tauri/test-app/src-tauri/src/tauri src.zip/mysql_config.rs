use mysql::*;
use serde::{Serialize, Deserialize};

#[derive(Serialize, Deserialize)]
pub struct Person {
    pub uuid:i32,
    pub name:String,
    pub old:i32,
    pub create_date:Option<String>
}

const CONNECT_STR: &str = "mysql://root:testDB123@localhost:1491/newOne";

pub fn use_mysql<T>(call_back: fn(connect:&mut Conn) -> T) -> T {
    let pool_connect = Pool::new(CONNECT_STR).unwrap();

    let mut connect = pool_connect.get_conn().unwrap();

    call_back(connect.as_mut())
}